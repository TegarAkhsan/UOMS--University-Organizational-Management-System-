
// This file is deprecated. 
// Role dashboards have been moved to pages/dashboards/ directory:
// - BendaharaDashboard.tsx
// - SekretarisDashboard.tsx
// - KadepDashboard.tsx
// - StaffDashboard.tsx

export const RoleDashboards = () => null;
