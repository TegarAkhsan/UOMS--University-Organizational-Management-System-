<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Assistance extends Model
{
    protected $fillable = ['program_id', 'no', 'description', 'status'];
    //
}
